// Copyright AnimalXStudio 2021


#include "Character/LucidMovementComponent.h"

ULucidMovementComponent::ULucidMovementComponent(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	bUseControllerDesiredRotation = true;
}
